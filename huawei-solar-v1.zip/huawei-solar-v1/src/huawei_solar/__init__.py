"""
interact async with the huawei inverter using modbus to get production data
"""
__version__ = "1.2.0"

from .huawei_solar import *  # noqa: F401 F403
